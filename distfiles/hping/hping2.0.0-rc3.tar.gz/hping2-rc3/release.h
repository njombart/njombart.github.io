/* 
 * $smu-mark$ 
 * $name: release.h$
 * $author: Salvatore Sanfilippo <antirez@invece.org>$
 * $copyright: Copyright (C) 1999 by Salvatore Sanfilippo$
 * $license: This software is under GPL version 2 of license$
 * $date: Fri Nov  16 11:55:49 MET 1999$
 * $rev: 17$
 */ 

#ifndef _RELEASE_H
#define _RELEASE_H

#define RELEASE_VERSION "2.0.0-rc3"
#define RELEASE_DATE "Mon May  3 10:56:19 CEST 2004"
#define CONTACTS "<antirez@invece.org>"

#endif /* _RELEASE_H */
