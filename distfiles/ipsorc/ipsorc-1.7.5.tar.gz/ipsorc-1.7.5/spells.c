/***************************************************************************
                          spells.c  -  more spells
                             -------------------
    begin                : Sat Sep 22 2001
    copyright            : (C) 2001 by Josiah Zayner
    email                : phric@legions.org
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "wand.h"

struct in_addr wherefromto(char *herefrom)
{
  struct in_addr addr;
  struct hostent *host;

  memset(&addr, '\0', sizeof(struct in_addr));

  if((host = gethostbyname(herefrom)) == NULL)
  {
     if(inet_aton(herefrom, &addr) == 0)
     { prterr("Cannot Resolve Host, please specify IP!"); }

  }
  else { memcpy(&addr, host->h_addr_list[0], sizeof(struct in_addr)); }

  return addr;
}



/* standard Internet Protocol checksum*/
unsigned short in_cksum(unsigned short *addr, int len)
{
  unsigned short answer;
  unsigned int sum = 0;
  unsigned short oddbyte = 0;

  /*
   * Our algorithm is simple, using a 32 bit accumulator (sum), we add
   * sequential 16 bit words to it, and at the end, fold back all the
   * carry bits from the top 16 bits into the lower 16 bits.
   */

  while (len > 1)
  {
    sum += *addr++;
    len -= 2;
  }

  /* mop up an odd byte, if necessary */
  if (len == 1)
  {
    *((unsigned char *)&oddbyte) = *(unsigned char *)addr ;
    sum += oddbyte;
  }

  /* add back carry outs from top 16 bits to low 16 bits */
  sum = (sum >> 16) + (sum & 0xffff); /* add hi 16 to low 16 */
  sum += (sum >> 16); /* add carry */
  answer = ~sum; /* truncate to 16 bits */
  return answer;
}


/* clear and allocate memory */
void *clalloc(int bytes)
{
  void *ret;
  if((ret = malloc(bytes)) == NULL)
  {
    fprintf(stderr,"Cannot allocate %d bytes memory!", bytes);
    exit(-1);
  }
  memset(ret,'\0', bytes);

  return ret;
}

char *TCP_FLAGS(u_char flags)
{
  char *flagswho  = clalloc(100);

    if(flags & TH_FIN) { strcat(flagswho, "FIN "); }
    if(flags & TH_SYN) { strcat(flagswho, "SYN "); }
    if(flags & TH_RST) { strcat(flagswho, "RST "); }
    if(flags & TH_PUSH) { strcat(flagswho, "PSH "); }
    if(flags & TH_ACK) { strcat(flagswho, "ACK "); }
    if(flags & TH_URG) { strcat(flagswho, "URG "); }
    if(flags & 0) { strcat(flagswho, "No Flags"); }


 return flagswho;
}
